~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ CHESS PLEASE ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Created by: Kingsmen
Date: 5 February 2018 
All Rights Reserved
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Welcome to Chess Please (Alpha Release)! In order to install your new copy of Chess
Please, please type the following series of commands into your command line:

	[user$] tar -xzvf Chess_Alpha.tar.gz
	[user$] make
	[user$] make gui 
	[user$] ./bin/ChessPlease_1.0
	[user$] ./bin/ChessPlease_1.0GUI 

This will unzip and initiate the executable program ChessPlease

				*** NOTE ***
make will make the standard ASCII version of the program while make gui creates
the GUI version of ChessPlease which is still in beta. make is recommended.
For more information, visit the user manual and the software spec sheet located 
in /doc/ 
